import java.io.*;
import java.net.*;







public class BruteForce {
public static ServerSocket Serverreseau;
	
public static void main (String[  ] argc) throws Exception
{
 int LPort = 9000;
 String[] pathnames;

        // Creates a new File instance by converting the given pathname string
        // into an abstract pathname
        File f = new File("/var/www/html/TP4/");

        // Populates the array with names of files and directories
        pathnames = f.list();

        // For each pathname in the pathnames array
        for (String pathname : pathnames) {
            // Print the names of files and directories
            System.out.println(pathname);
        }


		File file2 = new File("/var/www/html/TP4/renommage3.cgi");
  
        // Create an object of the File class
        // Replace the file path with path of the directory
        File rename = new File("/var/www/html/TP4/243.cgi");
  
        // store the return value of renameTo() method in
        // flag
        boolean flag = file2.renameTo(rename);
  
        // if renameTo() return true then if block is
        // executed
        if (flag == true) {
            System.out.println("File Successfully Rename");
        }
        // if renameTo() return false then else block is
        // executed
        else {
            System.out.println("Operation Failed");
        }








try {
Serverreseau = new ServerSocket(LPort); }

catch (Exception e1) {
System.out.println("overture refuser pour le port : " + LPort); }

System.out.println("numero du port: " + LPort);

while(true)
{
try(Socket client_Socket_t = Serverreseau.accept())
{
System.out.println("connexion client...");

InputStreamReader ISR = new InputStreamReader(client_Socket_t.getInputStream());

BufferedReader buffer_t = new BufferedReader(ISR);
				
while(!buffer_t.readLine().equals(""));

String Content = "";
String indPath = "/var/www/html/TP4/index.html";
BufferedReader indReader = new BufferedReader(new FileReader(indPath));
String line;

while( (line = indReader.readLine() )!=   null)
{
Content = Content.concat(line);
}
				
String ResponseHeader = "HTTP/1.1 200 O  K\n"
+ "content-type:text /  html;charset=  utf - 8 \n" 
+ "content-length:" + Content.getBytes().length + "\r\n\r\n";

				
String myData = ResponseHeader + Content;

				
client_Socket_t.getOutputStream().write(myData.getBytes("UTF-8"));


client_Socket_t.getOutputStream().flush();
				
client_Socket_t.close();
				}
		}
	}
	
	
}
